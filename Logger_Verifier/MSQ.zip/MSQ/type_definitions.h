//Message Type
int TYPE_CAMERA_CFG = 1;

//DEFINE
#define BUFF_SIZE	6

// DATA STURCT
typedef struct {
	long data_type;
	unsigned char data_buff[BUFF_SIZE];
} t_data;


