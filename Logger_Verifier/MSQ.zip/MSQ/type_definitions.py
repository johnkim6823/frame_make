#Message Type
TYPE_CAMERA_CFG = 1
TYPE_CONFRIM_CFG =2
#----------------------------
#Header size
CONFIG_HEADER_SIZE = 6
CONFIRM_HEADER_SIZE = 1
#----------------------------
#SIZE 
VGA = 0x01
HD = 0x02
CIF = 0x03
#----------------------------
#FORMAT
YUV420 = 0x21;
#----------------------------
