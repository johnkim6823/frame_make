#Message Type
TYPE_CAMERA_CFG = 1

#Header size
HEADER_SIZE = 6

#SIZE 
VGA = 0x01
HD = 0x02

#FPS

#FORMAT
YUV420 = 0x21;
