#include <iostream>
#include <string>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include "type_definitions.h"
#include "main_receiver.cpp"
#include "main_sender.cpp"

using namespace std;

int main() {

	msq_sender();
	msq_receiver();

	return 0;
}
