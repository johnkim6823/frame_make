
int TYPE_SIZE = 1;
int TYPE_FPS = 2;
int TYPE_FORMAT = 3;
