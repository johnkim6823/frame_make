#!/usr/bin/env python3
# http://weifan-tmm.blogspot.kr/2015/07/a-simple-turorial-for-python-c-inter.html
import sysv_ipc
import numpy as np
import struct

BUFF_SIZE = 8

from type_definitions import *

if __name__ == '__main__':
        
    msg_size = "VGA\0"
    msg_fps = 30
    msg_format = "YUV420\0"
    
    try:
        mq = sysv_ipc.MessageQueue(1234, sysv_ipc.IPC_CREAT)

        # size transmission
        mq.send(msg_size, True, type=TYPE_SIZE)
        print(f"SIZE sent: {msg_size}")

        # fps trasmission
        bytearray1 = struct.pack("i", msg_fps)
        mq.send(bytearray1, True, type=TYPE_FPS)
        print(f"FPS sent: {msg_fps}")
        
        # fps trasmission
        mq.send(msg_format, True, type=TYPE_SIZE)
        print(f"FPS sent: {msg_format}")


    except sysv_ipc.ExistentialError:
        print("ERROR: message queue creation failed")


